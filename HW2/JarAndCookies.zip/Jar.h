#ifndef JAR_H
#define JAR_H

#include "Cookie.h"

class Jar
{
    public:
        Jar();
        Jar(const Jar&);
        ~Jar();
        void addCookie(Cookie);
        void printAll();
        void removeCookieAtIndex(size_t index);
    protected:
    private:
        Cookie* cookies;
        void del();
        void resize(int newCap);
        void extend();
        size_t capacity;
        size_t size;
};

#endif // JAR_H
