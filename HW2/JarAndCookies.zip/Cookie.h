#ifndef COOKIE_H
#define COOKIE_H

#include <string.h>
#include <iostream>

class Cookie
{
    public:
        Cookie();
        Cookie(char**, size_t);
        Cookie(const Cookie& c);
        ~Cookie();
        Cookie& operator=(Cookie& c1);
        void getText() ;
    protected:
    private:
        void setText(char**,size_t);
        char** text;
        size_t numberOfWords;
        void destroy();
};

#endif
// COOKIE_H
